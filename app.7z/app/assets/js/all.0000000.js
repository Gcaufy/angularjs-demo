'use strict';

window.webapp = angular.module('webapp', ['ui.router', 
    'webapp.home',
    'webapp.daypass',
    'webapp.event',
    'webapp.dependent',
    'webapp.login',
    'webapp.account',
    'webapp.profile',
    'webapp.training'
]);

webapp.config(function($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.when("", "/");
    
    $stateProvider.state('app', {
        url : '/',
        templateUrl : 'web/index.html',
        controller: 'IndexCtrl'
    });
});



window.exports = {};

webapp.config(function ($httpProvider) {
    $httpProvider.interceptors.push('htmlCacheClear');
}); 
webapp.factory('htmlCacheClear', function ($q, $window) {
    return {
        request: function (config) {
        	if (config.method === 'GET' && config.url.substr(-5) === '.html') {
        		config.url += '?t=' + window.BUILD_HTML_HASH;
        	}
        	return config;
        }
    };
});


angular.module('webapp.home', ['ngRoute', 'ui.router'])
.controller('IndexCtrl', function($scope) {
	console.log('this is home page');
});

angular.module('webapp.account', [])
.config(function($stateProvider, $urlRouterProvider) {

	$stateProvider.state('app.member_myacc_01', {
		url : 'member_myacc_01',
		templateUrl : 'web/modules/account/member_myacc_01.html',
		controller: 'IndexCtrl'
	});
    $stateProvider.state('app.member_myacc_02', {
        url : 'member_myacc_02',
        templateUrl : 'web/modules/account/member_myacc_02.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.member_myacc_03', {
        url : 'member_myacc_03',
        templateUrl : 'web/modules/account/member_myacc_03.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.member_myacc_04', {
        url : 'member_myacc_04',
        templateUrl : 'web/modules/account/member_myacc_04.html',
        controller: 'IndexCtrl'
    });
});

angular.module('webapp.account')

.controller('IndexCtrl', function($scope) {
	console.log('this is event pagCCCCCe');
});

angular.module('webapp.daypass', [])
.config(function($stateProvider, $urlRouterProvider) {

	$stateProvider.state('app.daypass', {
		url : 'daypass',
		templateUrl : 'web/modules/daypass/index.html',
		controller: 'IndexCtrl'
	});
});

angular.module('webapp.daypass')

.controller('IndexCtrl', function($scope) {
	console.log('this is daypass page');
});

angular.module('webapp.dependent', [])
.config(function($stateProvider, $urlRouterProvider) {
    $stateProvider.state('app.member_dependent_01', {
        url : 'member_dependent_01',
        templateUrl : 'web/modules/dependent/list.html',
        controller: 'IndexCtrl'
    });
	$stateProvider.state('app.member_dependent_02', {
		url : 'member_dependent_02',
		templateUrl : 'web/modules/dependent/detail.html',
		controller: 'IndexCtrl'
	});
});

angular.module('webapp.dependent')

.controller('DetailCtrl', function($scope) {
	debugger;
	console.log('this is dependent page');
}); 

angular.module('webapp.dependent')

.controller('IndexCtrl', function($scope) {
	console.log('this is dependent page');
});

angular.module('webapp.event', [])
.config(function($stateProvider, $urlRouterProvider) {

	$stateProvider.state('app.member_event_01', {
		url : 'member_event_01',
		templateUrl : 'web/modules/event/list.html',
		controller: 'IndexCtrl'
	});
  $stateProvider.state('app.member_event_02', {
      url : 'member_event_02',
      templateUrl : 'web/modules/event/detail.html',
      controller: 'IndexCtrl'
  });
  $stateProvider.state('app.member_event_03', {
    url : 'member_event_03',
    templateUrl : 'web/modules/event/confirm_detail.html',
    controller: 'IndexCtrl'
  });
  $stateProvider.state('app.member_event_04', {
    url : 'member_event_04',
    templateUrl : 'web/modules/event/success.html',
    controller: 'IndexCtrl'
  });
});

angular.module('webapp.event')

.controller('IndexCtrl', function($scope) {
	console.log('this is event page');
});

angular.module('webapp.login', [])
.config(function($stateProvider, $urlRouterProvider) {

	$stateProvider.state('app.login1', {
		url : 'login1',
		templateUrl : 'web/modules/login/index.html',
		controller: 'IndexCtrl'
	});
    $stateProvider.state('app.login2', {
        url : 'login2',
        templateUrl : 'web/modules/login/index2.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.login3', {
        url : 'login3',
        templateUrl : 'web/modules/login/index3.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.login4', {
        url : 'login4',
        templateUrl : 'web/modules/login/index4.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.login5', {
        url : 'login5',
        templateUrl : 'web/modules/login/index5.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.login6', {
        url : 'login6',
        templateUrl : 'web/modules/login/index6.html',
        controller: 'IndexCtrl'
    });
});

angular.module('webapp.login')

.controller('IndexCtrl', function($scope) {
	console.log('this is event pagCCCCCe');
});

angular.module('webapp.profile', [])
.config(function($stateProvider, $urlRouterProvider) {

	$stateProvider.state('app.member_profile_01', {
		url : 'member_profile_01',
		templateUrl : 'web/modules/profile/edit.html',
		controller: 'IndexCtrl'
	});
    $stateProvider.state('app.member_profile_02', {
        url : 'member_profile_02',
        templateUrl : 'web/modules/profile/view.html',
        controller: 'IndexCtrl'
    });

});

angular.module('webapp.profile')

.controller('IndexCtrl', function($scope) {
	console.log('this is event pagCCCCCe');
});

angular.module('webapp.training', [])
.config(function($stateProvider, $urlRouterProvider) {

  $stateProvider.state('app.training', {
    url : 'training',
    templateUrl : 'web/modules/training/index.html',
    controller: 'IndexCtrl'
  });

	$stateProvider.state('app.02training', {
		url : '02training',
		templateUrl : 'web/modules/training/course/list.html',
		controller: 'IndexCtrl'
	});
  $stateProvider.state('app.03training', {
      url : '03training',
      templateUrl : 'web/modules/training/course/detail.html',
      controller: 'IndexCtrl'
  });
  $stateProvider.state('app.04training', {
    url : '04training',
    templateUrl : 'web/modules/training/course/confirm_detail.html',
    controller: 'IndexCtrl'
  });
  $stateProvider.state('app.05training', {
    url : '05training',
    templateUrl : 'web/modules/training/course/confirm_detail2.html',
    controller: 'IndexCtrl'
  });
  $stateProvider.state('app.06training', {
    url : '06training',
    templateUrl : 'web/modules/training/course/success.html',
    controller: 'IndexCtrl'
  });
  $stateProvider.state('app.07training_manual', {
    url : '07training_manual',
    templateUrl : 'web/modules/training/course/confirm_manually.html',
    controller: 'IndexCtrl'
  });
  $stateProvider.state('app.08training_manual', {
    url : '08training_manual',
    templateUrl : 'web/modules/training/course/success.html',
    controller: 'IndexCtrl'
  });

  // for private coach
    $stateProvider.state('app.01private_coaching', {
        url : '01private_coaching',
        templateUrl : 'web/modules/training/private_coaching/01private_coaching.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.02private_coaching', {
        url : '02private_coaching',
        templateUrl : 'web/modules/training/private_coaching/02private_coaching.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.03private_coaching', {
        url : '03private_coaching',
        templateUrl : 'web/modules/training/private_coaching/01private_coaching.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.04private_coaching', {
        url : '04private_coaching',
        templateUrl : 'web/modules/training/private_coaching/01private_coaching.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.05private_coaching', {
        url : '05private_coaching',
        templateUrl : 'web/modules/training/private_coaching/01private_coaching.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.06private_coaching', {
        url : '06private_coaching',
        templateUrl : 'web/modules/training/private_coaching/01private_coaching.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.07private_coaching', {
        url : '07private_coaching',
        templateUrl : 'web/modules/training/private_coaching/01private_coaching.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.08private_coaching', {
        url : '08private_coaching',
        templateUrl : 'web/modules/training/private_coaching/01private_coaching.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.09private_coaching', {
        url : '09private_coaching',
        templateUrl : 'web/modules/training/private_coaching/01private_coaching.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.10private_coaching', {
        url : '10private_coaching',
        templateUrl : 'web/modules/training/private_coaching/01private_coaching.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.11private_coaching', {
        url : '11private_coaching',
        templateUrl : 'web/modules/training/private_coaching/01private_coaching.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.12private_coaching', {
        url : '12private_coaching',
        templateUrl : 'web/modules/training/private_coaching/01private_coaching.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.13private_coaching', {
        url : '13private_coaching',
        templateUrl : 'web/modules/training/private_coaching/01private_coaching.html',
        controller: 'IndexCtrl'
    });
    $stateProvider.state('app.14private_coaching', {
        url : '14private_coaching',
        templateUrl : 'web/modules/training/private_coaching/01private_coaching.html',
        controller: 'IndexCtrl'
    });
});

angular.module('webapp.training')

.controller('IndexCtrl', function($scope) {
	console.log('this is event page');
});
