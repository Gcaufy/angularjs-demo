angular.module('webapp.event')

.controller('IndexCtrl', function($scope) {
	console.log('this is event page');
});
