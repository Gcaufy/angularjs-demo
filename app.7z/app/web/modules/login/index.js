angular.module('webapp.login')

.controller('IndexCtrl', function($scope) {
	console.log('this is event pagCCCCCe');
});
