angular.module('webapp.training')

.controller('IndexCtrl', function($scope) {
	console.log('this is event page');
});
