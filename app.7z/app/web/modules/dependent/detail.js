angular.module('webapp.dependent')

.controller('DetailCtrl', function($scope) {
	debugger;
	console.log('this is dependent page');
}); 
