angular.module('webapp.dependent')

.controller('IndexCtrl', function($scope) {
	console.log('this is dependent page');
});
