angular.module('webapp.account')

.controller('IndexCtrl', function($scope) {
	console.log('this is event pagCCCCCe');
});
