angular.module('webapp.daypass')

.controller('IndexCtrl', function($scope) {
	console.log('this is daypass page');
});
