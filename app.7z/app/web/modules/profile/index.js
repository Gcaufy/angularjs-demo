angular.module('webapp.profile')

.controller('IndexCtrl', function($scope) {
	console.log('this is event pagCCCCCe');
});
